Rithm UI brand assets
========================

Logo mark and wordmark, each in dark (for light backgrounds) and light
(for dark backgrounds), as SVG and transparent PNG, plus press-quality
product screenshots (rithm-ui-screenshot-*.png, light and dark).

Please keep the mark's shape, proportions, and colors as shipped — don't
redraw, recolor, or add effects.

Website  https://rithmui.com
Brand    https://rithmui.com/brandkit
GitHub   https://github.com/aadiexii/Rithm-UI
X        https://x.com/aadiexii
